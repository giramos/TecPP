﻿using System;
using System.Linq;


namespace Ejercicio3
{
    internal class Program
    {
        static void Main()
        {
            Console.WriteLine("Ejercicio 3...");
            int[] array = Enumerable.Range(0, 10).ToArray();
            
        }


    }
}
