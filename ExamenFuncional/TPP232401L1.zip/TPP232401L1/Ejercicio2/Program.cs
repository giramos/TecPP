﻿using System;


namespace Ejercicio2
{
    public class Program
    {
        static void Main()
        {
            Console.WriteLine("Ejercicio 2....");
            int[] secuencia = { 1, 2, 3, 4, 5, 6, 7, 8 };

        }

      
    }
}
