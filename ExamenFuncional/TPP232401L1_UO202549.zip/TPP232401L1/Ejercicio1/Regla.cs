﻿
using System;

namespace Ejercicio1
{
    /// <summary>
    /// Esta clase representa una regla.
    /// Una regla impone una condición para su cumplimiento.
    /// Dos reglas se consideran iguales si tienen el mismo mensaje de error.
    /// </summary>
    public class Regla
    {

        /// <summary>
        /// Mensaje que define el error que puede mostrarse cuando no se cumple la condición.
        /// </summary>
        public string MensajeError { get; }
        public readonly Predicate<int> condicion;

        public Regla(string mensajeError, Predicate<int> cond)
        {
            MensajeError = mensajeError;
            condicion = cond;
        }


        /// <summary>
        /// Este método DEBERÍA comprobrar si el elemento recibido cumple o no cumple con la condición de la regla.
        /// </summary>
        /// <param name="elemento">Elemento a validar</param>
        /// <returns>Verdadero si cumple la regla. Falso en caso contrario.</returns>
        public bool Validar(int elemento)
        {
            //Método incompleto.
            return condicion(elemento) ? true : false;

        }

        public override bool Equals(object obj)
        {
            return obj is Regla regla &&
                   MensajeError == regla.MensajeError;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(MensajeError, condicion);
        }
    }
}
