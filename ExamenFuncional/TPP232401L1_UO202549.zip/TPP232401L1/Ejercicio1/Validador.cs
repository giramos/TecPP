﻿using ListaGenerica;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio1
{
    public class Validador
    {
        Lista<Regla> lista;
        
        public Validador() { 
            lista = new Lista<Regla>();
        }

        public void InsertarRegla(Regla regla)
        {
            if (regla == null)
                throw new ArgumentException("No almacena null");
            lista.Añadir(regla);
        }

        public bool EliminarRegla(Regla regla)
        {
            lista.Borrar(regla);

            return true;
        }
        public bool Validar(int elemento) {
            bool result = false;
            Lista<string> listaerror = new();
            foreach (Regla regla in lista)
            {
                if (regla.Validar(elemento))
                {
                    result = true;
                    
                }
                else
                {
                    result = false;
                    listaerror.Añadir(regla.MensajeError);
                }
            }
            return result;
        }
    }
}
