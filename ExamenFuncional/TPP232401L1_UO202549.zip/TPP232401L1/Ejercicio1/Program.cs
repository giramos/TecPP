﻿using System;


namespace Ejercicio1
{
    internal class Program
    {
        static void Main()
        {
            Regla regla = new Regla("Esto es un mensaje de error genérico", e => e%2==0);
            int elemento = 5;

            //Recuerda: La clase Regla está incompleta.
            if (regla.Validar(elemento))
                Console.WriteLine("El elemento cumple con la regla. Es válido.");
            else
                Console.WriteLine("El elemento no cumple con la regla. Motivo: " + regla.MensajeError);

        }

     
    }
}
