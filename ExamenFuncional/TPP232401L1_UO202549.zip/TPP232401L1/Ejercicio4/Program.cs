﻿using System;
using System.Collections.Generic;
using System.Linq;
using Modelo;

namespace Ejercicio4
{

    internal class Program
    {
        private static Model modelo = new Model();
        static void Main()
        {
            ConsultaA();
            ConsultaB();
        }

        private static void ConsultaA()
        {
            Console.WriteLine("Consulta A....");
            var mediaEdad = modelo.Employees.Select(x => x.Age).Average();
            var res = modelo.Employees.Where(e => e.Age < mediaEdad).Select(e => $"Nombre: {e.Name} - Edad: {e.Age}");
            Show(res);
        }

        private static void ConsultaB()
        {
            Console.WriteLine("Consulta B....");
            var origen = modelo.Employees.Join(modelo.PhoneCalls, e => e.TelephoneNumber, p => p.SourceNumber, (e, p) => new
            {
                Empleado = e.Name,
                TelefonoEmpleado = e.TelephoneNumber,
                TelefonoOrigen = p.SourceNumber
            });

            var destino = modelo.Employees.Join(modelo.PhoneCalls, e => e.TelephoneNumber, p => p.DestinationNumber, (e, p) => new
            {
                Empleado = e.Name,
                TelefonoEmpleado = e.TelephoneNumber,
                TelefonoDestino = p.DestinationNumber
            });

            var res = origen.Join(destino, e => e.TelefonoOrigen, p => p.TelefonoDestino, (e, p) => new
            {
                e.Empleado,
                e.TelefonoOrigen,
                p.TelefonoDestino
            }).Where(e => e.TelefonoOrigen.Equals(e.TelefonoDestino)).Distinct().Select(e => $"{e.Empleado};{e.TelefonoDestino} ");

            Show(res);
        }

        private static void Show<T>(IEnumerable<T> colección)
        {
            foreach (var item in colección)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine("Elementos en la colección: {0}.", colección.Count());
        }
    }

    
}
