﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;

namespace Ejercicio2
{
    public class Program
    {
        static void Main()
        {
            Console.WriteLine("Ejercicio 2....");
            int[] secuencia = { 1, 2, 3, 4, 5, 6, 7, 8 };

        }

        
    }

    public static class Extensor {
        public static IEnumerable<IEnumerable<T>> Trocear<T>(this IEnumerable<T> col,  int n, bool conresto)
        {
            IEnumerable <IList<T>> enume = new List<List<T>> ();
            IList<T> lista = new List<T> (n);
            var a = col.GetEnumerator ();
        }
    }

}
