﻿using System;
using System.Collections.Generic;
using System.Linq;


namespace Ejercicio3
{
    internal class Program
    {
        static void Main()
        {
            Console.WriteLine("Ejercicio 3...");
            int[] array = Enumerable.Range(0, 10).ToArray();
            Func<int> current;
            Func<bool> moveNext;
            Action Reset;
            Enum(array,out current,out moveNext,out Reset);
            for (int iiii = 0; iiii < array.Length; iiii++)
            {
                Console.WriteLine(moveNext());
            }

        }
        public static void Enum<T>(IEnumerable<T> col, out Func<T> current, out Func<bool> moveNext, out Action Reset)
        {
            current = () => col.GetEnumerator().Current;
            Reset = () => col.GetEnumerator().Reset();
            moveNext = () => col.GetEnumerator().MoveNext();   
        }


    }
}
