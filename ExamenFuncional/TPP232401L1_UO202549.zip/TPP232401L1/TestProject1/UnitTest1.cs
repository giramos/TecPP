using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Runtime.InteropServices;
namespace TestProject1
{
    [TestClass]
    public class UnitTest1
    {
        Lista listaPeque�a = new Lista();
        Lista listaGrande = new Lista();
        Lista listaChar = new Lista();
        Lista listaDouble = new Lista();
        Lista listaString = new Lista();
        Lista listaMiscelanea = new Lista();
        Lista listaNull = new Lista();
        Pila pila = new Pila(5);

        [TestInitialize]
        public void Inicio()
        {
            // Lista enteros peque�a
            for (int i = 0; i < 5; i++)
            {
                listaPeque�a.A�adir(i);
            }

            // Lista grande enteros
            for (int i = 0; i < 50; i++)
            {
                listaGrande.A�adir(i);
            }

            // Lista de caracteres
            char[] caracteres = new[] { 'A', 'B', 'C', 'D' };
            for (int i = 0; i < caracteres.Length; i++)
            {
                listaChar.A�adir(caracteres[i], i);
            }

            // Lista de dobles
            for (double i = 0.0; i < 5.0; i = i + 0.5)
            {
                listaDouble.A�adir(i);
            }

            // Lista de string
            string[] cadenas = new[] { "hola", "adios", "bien", "mal" };
            for (int i = 0; i < cadenas.Length; i++)
            {
                listaString.A�adir(cadenas[i], i);
            }

            // Lista miscel�nea (MIXTA)
            listaMiscelanea.A�adir(1);
            listaMiscelanea.A�adir('a');
            listaMiscelanea.A�adir(1.5);
            listaMiscelanea.A�adir("german");

            // Lista con null
            for (int i = 0; i < 5; i++) { listaNull.A�adir(null); }

            // Pila
            pila.Push('a');
            pila.Push(1);
            pila.Push("dos");
            pila.Push(3.0);


        }

        [TestMethod]
        public void TestA�adirInicio()
        {
            // A�adimos al inicio 
            listaPeque�a.A�adirInicio(1);
            Assert.IsTrue(listaPeque�a.NumElementos.Equals(6));
            Assert.IsFalse(listaPeque�a.ListaVacia());
            Assert.AreEqual("[1 - 0 - 1 - 2 - 3 - 4 - ]", listaPeque�a.ToString());
        }
}
