﻿using Modelo;
using System;

namespace Ejercicio1
{
    internal class Program
    {
        static void Main()
        {
            Console.WriteLine($"Tamaño del listado de palabras: {Palabras.listado.Length} palabras.");
        }        
    }
}
