﻿using System;
using System.Linq;

namespace Prueba
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var palabra = "German";
             var res = CalcularPrimerasDosLetras(palabra);

            Console.WriteLine(res.ToString());

            var res1 = CalcularUltimasDosLetras(palabra);

            Console.WriteLine(res1.ToString());
        }

       
        private static string CalcularPrimerasDosLetras(string v)
        {
            string str = "";
            for(int i=0; i<2; i++)
            {
                str += v[i];
            }
            return str;
        }

        private static string CalcularUltimasDosLetras(string v)
        {
            string str = "";
            for (int i = v.Length-1; i >= v.Length-2 ; i--)
            {
                str += v[i];
            }
            return str;
        }

        

        private static string CalcularUltimasDosLetras2(string v)
        {
            string str = "";
            for (int i = v.Length - 3; i >= v.Length; i--)
            {
                str += v[i];
            }
            return str;
        }

    }
}
