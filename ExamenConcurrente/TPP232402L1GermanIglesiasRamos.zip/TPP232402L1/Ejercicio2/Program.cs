﻿using ColaConcurrente;
using Modelo;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Ejercicio2
{
    internal class Program
    {
        static readonly object ob = new object();
        static List<int> threadIds = new();
        static void Main()
        {
            Console.WriteLine($"Tamaño del listado de palabras: {Palabras.listado.Length} palabras.");
            var palabras = Palabras.listado;
            Cola<string> palabrasMasVocales = new Cola<string>();
            Cola<string> palabrasMasConsonanters = new Cola<string>();

            // Dividir las palabras en dos listas utilizando Parallel.ForEach
            Parallel.ForEach(palabras, palabra =>
            {
                if (TieneMasVocales(palabra))
                {
                    lock (ob)
                    {
                        palabrasMasVocales.Añadir(palabra);
                    }
                }
                else
                {
                    lock (ob)
                    {
                        palabrasMasVocales.Añadir(palabra);
                    }
                }
                lock (threadIds)
                {
                    if (!threadIds.Contains(Thread.CurrentThread.ManagedThreadId))
                    {
                        Console.WriteLine("Identificador hilo: " + Thread.CurrentThread.ManagedThreadId); // Lo ponemos por pantalla
                        threadIds.Add(Thread.CurrentThread.ManagedThreadId);
                    }
                }
            }
            );

            Console.WriteLine($"Número total de hilos: {threadIds.Count}");


            var suma = palabrasMasVocales.Count() + palabrasMasConsonanters.Count();
            Console.WriteLine("Suma " + suma);


            ////////
            ///


            Cola<string> masConsonantes = new();
            Cola<string> masVocales = new();




            Parallel.Invoke(
                () => masConsonantes = ContarVocales(palabras),
                () => masVocales = ContarConsonnantes(palabras)
                );

            // Imprime los resultados

            var sumaIn = masConsonantes.Count() + masVocales.Count();
            Console.WriteLine("SUma invoke " + sumaIn);

        }

        private static Cola<string> ContarConsonnantes(string[] palabras)
        {
            Cola<string> cola = new();
            foreach (var palabra in palabras)
            {
                if (!TieneMasVocales(palabra))
                {
                    cola.Añadir(palabra);
                }
            }
            return cola;
        }

        private static Cola<string> ContarVocales(string[] palabras)
        {
            Cola<string> cola = new();
            foreach (var palabra in palabras)
            {
                if (TieneMasVocales(palabra))
                {
                    cola.Añadir(palabra);
                }
            }
            return cola;
        }

        private static bool TieneMasVocales(string palabra)
        {
            int vocales = 0;
            int consonantes = 0;
            foreach (char word in palabra)
            {
                if (EsVocal(word))
                {
                    vocales++;
                }
                else if (EsConsonante(word))
                {
                    consonantes++;
                }
            }
            if (vocales > consonantes)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private static bool EsVocal(char letra)
        {
            return "aeiou".Contains(char.ToLower(letra));
        }
        static bool EsConsonante(char letra)
        {
            return "bcdfghjklmnpqrstvwxyz".Contains(char.ToLower(letra));
        }
    }
}
