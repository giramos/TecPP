﻿using Modelo;
using System;
using System.Collections.Generic;
using System.Threading;

namespace Ejercicio1
{
    internal class Program
    {
        private static List<int> threadIds = new();
        private static readonly object obj = new();
        static void Main()
        {
            Console.WriteLine($"Tamaño del listado de palabras: {Palabras.listado.Length} palabras.");
            var palabras = Palabras.listado;

            Thread[] hilos1 = new Thread[2];
            Thread[] hilos2 = new Thread[2];
            List<char> listavocales = new List<char>();
            List<char> listaconsonantes = new List<char>();

            for (int i = 0; i < 2; i++)
            {
                hilos1[i] = new Thread(
                    () =>
                    {
                        LetrasEncontradas(palabras, listavocales, true);
                        lock (obj)
                        {
                            if (!threadIds.Contains(Thread.CurrentThread.ManagedThreadId))
                            {
                                Console.WriteLine("Identificador hilo: " + Thread.CurrentThread.ManagedThreadId); // Lo ponemos por pantalla
                                threadIds.Add(Thread.CurrentThread.ManagedThreadId);
                            }
                        }
                    }
                    );
                hilos2[i] = new Thread(
                    () =>
                    {
                        LetrasEncontradas(palabras, listaconsonantes, false);
                        lock (obj)
                        {
                            if (!threadIds.Contains(Thread.CurrentThread.ManagedThreadId))
                            {
                                Console.WriteLine("Identificador hilo: " + Thread.CurrentThread.ManagedThreadId); // Lo ponemos por pantalla
                                threadIds.Add(Thread.CurrentThread.ManagedThreadId);
                            }
                        }
                    }
                    );
                hilos1[i].Start();
                hilos2[i].Start();
                hilos1[i].Join();
                hilos2[i].Join();
            }



            Console.WriteLine($"Número total de hilos: {threadIds.Count}");
            Console.WriteLine("Lista de vocales " + listavocales.Count);

            Console.WriteLine("Lista de consonantes " + listaconsonantes.Count);

            var suma = listaconsonantes.Count + listavocales.Count;
            //listavocales.ForEach(Console.WriteLine);
            Console.Write("Suma: " + suma);

        }

        private static void LetrasEncontradas(string[] palabras, List<char> lista, bool vocal)
        {
            foreach (string palabra in palabras)
            {
                foreach (char c in palabra)
                {
                    if ("AEIOUaeiou".Contains(c) && vocal == true)
                    {
                        lista.Add(c);
                    }
                    else if (!"AEIOUaeiou".Contains(c) && vocal == false)
                    {
                        lista.Add(c);
                    }
                }

            }
        }
    }
}
