﻿using Modelo;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

namespace Ejercicio3
{


    internal class Program
    {
        static void Main(string[] args)
        {
            const int maximoHilos = 30;


            Console.WriteLine($"Tamaño del listado de palabras: {Palabras.listado.Length} palabras.");

            var pal = Palabras.listado;


            MostrarLinea(Console.Out, "Num Hilos", "Ticks", "Resultado");
            for (int numeroHilos = 1; numeroHilos <= maximoHilos; numeroHilos++)
            {
                // Crear el Master con el vector y el número de hilos actual
                Master master = new Master(pal, numeroHilos);

                // Registrar el tiempo de inicio
                DateTime antes = DateTime.Now;


                var resultado = master.Calcular();

                // Registrar el tiempo de fin
                DateTime despues = DateTime.Now;

                // Calcular el tiempo de ejecución
                TimeSpan tiempoEjecucion = despues - antes;

                // Mostrar la línea de resultados
                MostrarLinea(Console.Out, numeroHilos, tiempoEjecucion.Ticks, resultado.Count);

                GC.Collect();
                GC.WaitForFullGCComplete();


            }

        }

        // Método para mostrar una línea de resultados en la consola
        static void MostrarLinea(System.IO.TextWriter stream, string numHilosCabecera, string ticksCabecera, string resultadoCabecera)
        {
            stream.WriteLine("{0};{1};{2}", numHilosCabecera, ticksCabecera, resultadoCabecera);
        }

        // Método para mostrar una línea de resultados en la consola
        static void MostrarLinea(System.IO.TextWriter stream, int numHilos, long ticks, int resultado)
        {
            stream.WriteLine("{0};{1:N0};{2:N0}", numHilos, ticks, resultado);
        }
    }

    // Clase Master que coordina el trabajo de los Workers
    public class Master
    {
        private string[] vector;
        private int numeroHilos;

        public Master(string[] vector, int numeroHilos)
        {
            if (numeroHilos < 1 || numeroHilos > 30) // Limitamos el número máximo de hilos a 30
                throw new ArgumentException("El número de hilos debe ser mayor que cero y menor o igual a 30");
            this.vector = vector;
            this.numeroHilos = numeroHilos;
        }

        // Método para calcular las parejas consecutivas y contarlas
        public List<(string, string)> Calcular()
        {
            //Dictionary<string, int> parejasConsecutivas = new Dictionary<string, int>();
            List<(string, string)> listaComun = new();

            Worker[] workers = new Worker[this.numeroHilos];
            int numElementosPorHilo = this.vector.Length / numeroHilos;
            int indiceInicio = 0;

            // Crear y ejecutar los Workers
            for (int i = 0; i < this.numeroHilos; i++)
            {
                int indiceFin = (i == this.numeroHilos - 1) ? this.vector.Length : indiceInicio + numElementosPorHilo;
                workers[i] = new Worker(this.vector, indiceInicio, indiceFin);
                indiceInicio = indiceFin;
            }

            // Iniciar los hilos
            Thread[] hilos = new Thread[workers.Length];
            for (int i = 0; i < workers.Length; i++)
            {
                hilos[i] = new Thread(workers[i].Calcular);
                hilos[i].Start();
            }

            // Esperar a que acaben los hilos
            foreach (Thread thread in hilos)
                thread.Join();


            foreach (Worker worker in workers)
            {
                foreach (var i in worker.Resultado)
                {
                    listaComun.Add(i);
                }
            }

            return listaComun;
        }
    }

    // Clase Worker que realiza el procesamiento de la lista de números
    internal class Worker
    {
        private string[] vector;
        private List<(string, string)> res = new();

        public List<(string, string)> Resultado { get { return res; } }
        private int indiceInicio, indiceFin;
        private static readonly object lockObject = new object(); // Objeto de bloqueo para sincronización

        internal Worker(string[] vector, int indiceInicio, int indiceFin)
        {
            this.vector = vector;
            //this.listaComun = listaComun;
            this.indiceInicio = indiceInicio;
            this.indiceFin = indiceFin;
        }

        // Método para encontrar parejas consecutivas
        internal void Calcular()
        {
            var listaComun = new List<(string, string)>();
            for (int i = this.indiceInicio; i < this.indiceFin - 1; i++)
            {
                if (CalcularUltimasDosLetras(vector[i]).Equals(CalcularPrimerasDosLetras(vector[i + 1])))
                {
                    lock (lockObject) // Bloqueo para asegurar el acceso seguro a la lista compartida
                    {
                        listaComun.Add((CalcularUltimasDosLetras(vector[i]), CalcularPrimerasDosLetras(vector[i + 1])));
                    }
                }
            }
            foreach (var item in listaComun)
            {
                res.Add(item);
            }
        }

        private static string CalcularPrimerasDosLetras(string v)
        {
            string str = "";
            for (int i = 0; i < 2; i++)
            {
                str += v[i];
            }
            return str;
        }

        private static string CalcularUltimasDosLetras(string v)
        {
            string str = "";
            for (int i = v.Length - 1; i >= v.Length - 2; i--)
            {
                str += v[i];
            }
            return str;
        }
    }

}
