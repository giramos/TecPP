﻿using System;

namespace TrabajoEnClase
{
    public class Producto
    {
        public string Nombre { get; set; }
        public string Descripcion { get; set; }
        public int Stock { get; set; }
        public bool Disponibilidad { get; set; }
        public Producto(string name, string des, int sto, bool dis)
        {
            Nombre = name;
            Descripcion = des;
            Stock = sto;
            Disponibilidad = dis;
        }

        public void Reponer(int unidades)
        {
            Stock += unidades;
        }
        public void Eliminar(int unidades)
        {
            Stock -= unidades;
        }


    }
}
