﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrabajoEnClase
{
    public interface IFacturable
    {
        // Indica el precio base
        int GetBase(double @double);
        // Indica el tipo de IVA
        int GetTipoIva(double @double);


    }
}
