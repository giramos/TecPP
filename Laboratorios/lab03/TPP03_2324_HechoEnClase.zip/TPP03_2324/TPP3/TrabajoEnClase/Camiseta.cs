﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace TrabajoEnClase
{
    internal class Camiseta : Producto
    {
        public string Talla { get; set; }
        public string Color { get; set; }

        public Camiseta(string name, string des, int sto, bool dis, string tal, string col) : base(name, des, sto, dis)
        {
            Talla = tal;
            Color = col;
        }
    }
}
